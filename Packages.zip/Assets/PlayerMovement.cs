using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;

    void Update()
    {
        // Get input for movement.
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        // Move the player based on input.
        Vector2 movement = new Vector2(horizontalInput, verticalInput);
        transform.position += (Vector3)movement * speed * Time.deltaTime;
    }
}
