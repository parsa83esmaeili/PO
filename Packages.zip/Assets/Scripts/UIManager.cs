using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public GameObject slotPrefab;
    public Transform slotParent;
    public GameObject settingsPanel;
    public GameObject settingsCross;

    void Start()
    {
        CreateSlots();
        CreateSettingsPanel();
    }

    void CreateSlots()
    {
        for (int i = 1; i <= 9; i++)
        {
            GameObject newSlot = Instantiate(slotPrefab, slotParent);
            newSlot.name = "Inventory Slot " + i;
            Image slotImage = newSlot.GetComponent<Image>();
            slotImage.sprite = Resources.Load<Sprite>("UI/Assets/Inventory_Slot_" + i);
        }
    }

    void CreateSettingsPanel()
    {
        settingsPanel.SetActive(true);
        settingsCross.SetActive(true);
    }
}